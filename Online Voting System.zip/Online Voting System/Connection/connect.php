<?php
    $connect = mysqli_connect("localhost", "root", "", "ovs") or die("Connection Failed");
	if($connect){
		echo "connected";
	}
	


?>