<?php
    include("connect.php");
	
	$name = $_POST['name'];
	$father_name = $_POST['father_name'];
	$email = $_POST['email'];
	$date_of_birth = $_POST['date_of_birth'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	$address = $_POST['address'];
	$image = $_FILES['photo']['name'];
	$tmp_name = $_FILES['photo']['tmp_name'];
	$role = $_POST['role'];
	
	if($password==$cpassword){
		move_uploaded_file($tmp_name, "../Pic/$image");
		$insert = mysqli_query($connect, "INSERT INTO user (name, father_name, email, date_of_birth, address, password, photo, role, status, votes) VALUES ('$name', '$father_name', '$email', '$date_of_birth', '$address', '$password', '$image', '$role', 0, 0)");
	    if($insert){
			echo'
		        <script>
		            alert("Registration Successful!");
		            window.location = "../";
		        </script>
		    ';
		}
        else{
			echo'
		        <script>
		            alert("Some Error Occured!");
		            window.location = "../New/reg.html";
		        </script>
		    ';
		}		
	}
	else{
		echo'
		    <script>
		        alert("Password and Confirm Password does not match!");
		        window.location = "../New/reg.html";
		    </script>
		';

	}

?>